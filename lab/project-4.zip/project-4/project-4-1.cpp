#include <iostream>    

using namespace std;

// Student ID 1:
// Student ID 2: 


/* For each of the below functions write:
(IMPT! Do these steps in order)
1. A stub
2. (In main) at least 2 tests (different array inputs)
3. Full function definition (comment out the stub)
*/


// contains_word: char[], int, string -> bool
// Accepts a character array (and its length), and a word
// as a string, and returns true if the word can be found
// in the array. I.e. each letter in the given word can 
// be found in the character array in order 


int main () {
  cout << boolalpha;
  
  
  cout << endl;

  return 0;
}